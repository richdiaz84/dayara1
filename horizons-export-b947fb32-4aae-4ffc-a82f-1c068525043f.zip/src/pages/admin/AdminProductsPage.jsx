
    import React, { useState, useEffect, useCallback } from 'react';
    import AdminProductForm from '@/components/admin/AdminProductForm';
    import ProductList from '@/components/admin/products/ProductList';
    import ProductActions from '@/components/admin/products/ProductActions';
    import { supabase } from '@/lib/supabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent } from '@/components/ui/dialog';
    import { motion, AnimatePresence } from 'framer-motion';
    import { RefreshCw } from 'lucide-react';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";

    const AdminProductsPage = () => {
      const [products, setProducts] = useState([]);
      const [isLoading, setIsLoading] = useState(false);
      const [isFormOpen, setIsFormOpen] = useState(false);
      const [productToEdit, setProductToEdit] = useState(null);
      const [searchTerm, setSearchTerm] = useState('');
      const [productToDelete, setProductToDelete] = useState(null);
      const { toast } = useToast();

      const fetchProducts = useCallback(async (currentSearchTerm = searchTerm) => {
        setIsLoading(true);
        try {
          let query = supabase.from('products').select('*').order('created_at', { ascending: false });
          if (currentSearchTerm) {
            query = query.or(`name.ilike.%${currentSearchTerm}%,description.ilike.%${currentSearchTerm}%,category.ilike.%${currentSearchTerm}%,barcode.ilike.%${currentSearchTerm}%`);
          }
          const { data, error } = await query;

          if (error) throw error;
          setProducts(data || []);
        } catch (error) {
          toast({ variant: "destructive", title: "Error", description: `Error al cargar productos: ${error.message}` });
        } finally {
          setIsLoading(false);
        }
      }, [searchTerm, toast]);
      
      const debouncedFetchProducts = useCallback(
        debounce((term) => fetchProducts(term), 500),
        [fetchProducts] 
      );

      useEffect(() => {
        debouncedFetchProducts(searchTerm);
        return () => {
          debouncedFetchProducts.cancel && debouncedFetchProducts.cancel();
        };
      }, [searchTerm, debouncedFetchProducts]);


      const handleAddProduct = () => {
        setProductToEdit(null);
        setIsFormOpen(true);
      };

      const handleEditProduct = (product) => {
        setProductToEdit(product);
        setIsFormOpen(true);
      };

      const handleFormSubmit = async (formData, productId) => {
        setIsLoading(true);
        try {
          if (productId) {
            const { error } = await supabase.from('products').update(formData).eq('id', productId);
            if (error) throw error;
            toast({ title: "Éxito", description: "Producto actualizado correctamente." });
          } else {
            const { error } = await supabase.from('products').insert(formData);
            if (error) throw error;
            toast({ title: "Éxito", description: "Producto añadido correctamente." });
          }
          setIsFormOpen(false);
          fetchProducts(searchTerm);
        } catch (error) {
          toast({ variant: "destructive", title: "Error", description: `Error al guardar producto: ${error.message}` });
          return Promise.reject(error);
        } finally {
          setIsLoading(false);
        }
        return Promise.resolve();
      };
      
      const deleteProductImages = async (imageUrls) => {
        if (!imageUrls || imageUrls.length === 0) return;
        
        const filePaths = imageUrls.map(url => {
          try {
            const parsedUrl = new URL(url);
            const pathParts = parsedUrl.pathname.split('/');
            // Assuming structure is /storage/v1/object/public/product_images/file_name.jpg
            const bucketNameIndex = pathParts.findIndex(part => part === 'product_images');
            if (bucketNameIndex !== -1 && bucketNameIndex + 1 < pathParts.length) {
              return pathParts.slice(bucketNameIndex + 1).join('/');
            }
            return null;
          } catch (e) {
            console.error("Invalid URL for deletion:", url, e);
            return null;
          }
        }).filter(path => path);

        if (filePaths.length > 0) {
          const { error } = await supabase.storage.from('product_images').remove(filePaths);
          if (error) {
            console.error('Error deleting images from storage:', error);
            toast({
              variant: "destructive",
              title: "Error de Almacenamiento",
              description: `No se pudieron eliminar algunas imágenes: ${error.message}`,
            });
          }
        }
      };

      const confirmDeleteProduct = (product) => {
        setProductToDelete(product);
      };

      const handleDeleteProduct = async () => {
        if (!productToDelete) return;
        setIsLoading(true);
        try {
          await deleteProductImages(productToDelete.images);
          // Also delete videos associated with the product
          await supabase.from('product_videos').delete().eq('product_id', productToDelete.id);
          // Delete product reviews
          await supabase.from('product_reviews').delete().eq('product_id', productToDelete.id);
          // Delete user video access records
          await supabase.from('user_product_video_access').delete().eq('product_id', productToDelete.id);

          const { error } = await supabase.from('products').delete().eq('id', productToDelete.id);
          if (error) throw error;
          toast({ title: "Éxito", description: "Producto y datos asociados eliminados correctamente." });
          fetchProducts(searchTerm);
        } catch (error) {
          toast({ variant: "destructive", title: "Error", description: `Error al eliminar producto: ${error.message}` });
        } finally {
          setIsLoading(false);
          setProductToDelete(null);
        }
      };

      const handleTogglePublish = async (product) => {
        setIsLoading(true);
        try {
          const { error } = await supabase
            .from('products')
            .update({ is_published: !product.is_published, updated_at: new Date().toISOString() })
            .eq('id', product.id);
          if (error) throw error;
          toast({ title: "Éxito", description: `Producto ${!product.is_published ? 'publicado' : 'ocultado'}.` });
          fetchProducts(searchTerm);
        } catch (error) {
          toast({ variant: "destructive", title: "Error", description: `No se pudo actualizar el estado: ${error.message}` });
        } finally {
          setIsLoading(false);
        }
      };
      
      function debounce(func, wait) {
        let timeout;
        const debouncedFunction = function(...args) {
            const context = this;
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(context, args), wait);
        };
        debouncedFunction.cancel = () => {
            clearTimeout(timeout);
        };
        return debouncedFunction;
      }


      return (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto py-8 px-4 md:px-6"
        >
          <ProductActions
            onAddProduct={handleAddProduct}
            onRefreshProducts={() => fetchProducts(searchTerm)}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            isLoading={isLoading}
          />

          {isLoading && products.length === 0 ? (
            <div className="flex justify-center items-center h-64">
              <RefreshCw className="h-12 w-12 animate-spin text-primary" />
            </div>
          ) : !isLoading && products.length === 0 && searchTerm ? (
            <p className="text-center text-muted-foreground mt-10">No se encontraron productos para "{searchTerm}".</p>
          ) : (
            <ProductList
              products={products}
              onEdit={handleEditProduct}
              onDelete={confirmDeleteProduct}
              onTogglePublish={handleTogglePublish}
              isLoading={isLoading}
            />
          )}

          <AnimatePresence>
            {isFormOpen && (
              <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if(!isOpen) { setIsFormOpen(false); setProductToEdit(null);}}}>
                <DialogContent className="max-w-3xl p-0 overflow-hidden" 
                   onInteractOutside={(e) => {
                     if (isLoading) e.preventDefault();
                   }}
                >
                  <AdminProductForm
                    productToEdit={productToEdit}
                    onFormSubmit={handleFormSubmit}
                    onCancel={() => { setIsFormOpen(false); setProductToEdit(null); }}
                  />
                </DialogContent>
              </Dialog>
            )}
          </AnimatePresence>

          <AlertDialog open={!!productToDelete} onOpenChange={(isOpen) => !isOpen && setProductToDelete(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Confirmar Eliminación?</AlertDialogTitle>
                <AlertDialogDescription>
                  Estás a punto de eliminar el producto "{productToDelete?.name}". Esta acción también eliminará videos, reseñas y accesos asociados. No se puede deshacer.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setProductToDelete(null)}>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteProduct} className="bg-destructive hover:bg-destructive/90">
                  Eliminar
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

        </motion.div>
      );
    };

    export default AdminProductsPage;
  