
    import React from 'react';
    import { NavLink, Link } from 'react-router-dom';
    import { Home, Package, Users, BarChart2, Settings, Palette, Image as ImageIcon, LogOut, ChevronDown, ChevronUp, ShieldCheck } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { useAuth } from '@/contexts/AuthContext';
    import { motion, AnimatePresence } from 'framer-motion';

    const AdminSidebar = ({ isSidebarOpen, toggleSidebar }) => {
      const { user, signOut, userRole } = useAuth();
      const [isSettingsOpen, setIsSettingsOpen] = React.useState(false);

      const navItems = [
        { name: 'Dashboard', icon: <Home className="h-5 w-5" />, path: '/admin' },
        { name: 'Productos', icon: <Package className="h-5 w-5" />, path: '/admin/products' },
        { name: 'Usuarios', icon: <Users className="h-5 w-5" />, path: '/admin/users' },
        { name: 'Reportes', icon: <BarChart2 className="h-5 w-5" />, path: '/admin/reports' },
        { name: 'Banners', icon: <ImageIcon className="h-5 w-5" />, path: '/admin/banners' },
      ];

      const settingsSubItems = [
        { name: 'General', path: '/admin/settings/general' },
        { name: 'Pagos', path: '/admin/settings/payments' },
        { name: 'Envíos', path: '/admin/settings/shipping' },
      ];

      const handleSignOut = async () => {
        await signOut();
        // Navigate to home or login, handled by AuthContext or ProtectedRoute
      };
      
      const linkVariants = {
        initial: { opacity: 0, x: -20 },
        animate: { opacity: 1, x: 0 },
        exit: { opacity: 0, x: -20 }
      };

      return (
        <aside className={`fixed inset-y-0 left-0 z-50 flex flex-col bg-card border-r border-border transition-all duration-300 ease-in-out ${isSidebarOpen ? 'w-64' : 'w-20'} overflow-y-auto`}>
          <div className="flex items-center justify-between h-20 px-4 border-b border-border shrink-0">
            <Link to="/admin" className={`flex items-center overflow-hidden ${isSidebarOpen ? 'w-auto' : 'w-full justify-center'}`}>
              <img  alt="Admin Logo" className="h-10 object-contain" src="https://images.unsplash.com/photo-1539369189415-69494ea05342" />
              <AnimatePresence>
              {isSidebarOpen && (
                <motion.span 
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: 'auto', transition: { delay: 0.1, duration: 0.2 } }}
                  exit={{ opacity: 0, width: 0, transition: { duration: 0.2 } }}
                  className="ml-3 text-xl font-bold text-primary whitespace-nowrap"
                >
                  Dayara Admin
                </motion.span>
              )}
              </AnimatePresence>
            </Link>
            <Button variant="ghost" size="icon" className="lg:hidden text-muted-foreground" onClick={toggleSidebar}>
              {isSidebarOpen ? <ChevronUp /> : <ChevronDown />}
            </Button>
          </div>

          <nav className="flex-1 px-2 py-4 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                end={item.path === '/admin'}
                className={({ isActive }) =>
                  `flex items-center py-2.5 px-3 rounded-lg transition-colors duration-150 group
                  ${isSidebarOpen ? 'justify-start' : 'justify-center'}
                  ${isActive ? 'bg-primary text-primary-foreground shadow-md' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`
                }
                title={isSidebarOpen ? '' : item.name}
              >
                {item.icon}
                <AnimatePresence>
                {isSidebarOpen && (
                  <motion.span 
                    variants={linkVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                    transition={{ duration: 0.2, delay: 0.1 }}
                    className="ml-3 whitespace-nowrap"
                  >
                    {item.name}
                  </motion.span>
                )}
                </AnimatePresence>
              </NavLink>
            ))}

            {/* Settings Dropdown */}
            <div>
              <button
                onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                className={`flex items-center w-full py-2.5 px-3 rounded-lg transition-colors duration-150 group text-muted-foreground hover:bg-muted hover:text-foreground
                ${isSidebarOpen ? 'justify-between' : 'justify-center'}`}
                title={isSidebarOpen ? '' : 'Configuración'}
              >
                <div className="flex items-center">
                  <Settings className="h-5 w-5" />
                  <AnimatePresence>
                  {isSidebarOpen && (
                    <motion.span 
                      variants={linkVariants}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                      transition={{ duration: 0.2, delay: 0.1 }}
                      className="ml-3 whitespace-nowrap"
                    >
                      Configuración
                    </motion.span>
                  )}
                  </AnimatePresence>
                </div>
                {isSidebarOpen && (isSettingsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />)}
              </button>
              <AnimatePresence>
                {isSettingsOpen && isSidebarOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden pl-6"
                  >
                    {settingsSubItems.map((subItem) => (
                      <NavLink
                        key={subItem.name}
                        to={subItem.path}
                        className={({ isActive }) =>
                          `flex items-center py-2 px-3 mt-1 rounded-lg transition-colors duration-150 group text-sm
                          ${isActive ? 'text-primary font-semibold' : 'text-muted-foreground hover:text-foreground'}`
                        }
                      >
                        {subItem.name}
                      </NavLink>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </nav>

          <div className="mt-auto p-4 border-t border-border">
            {user && (
              <div className={`flex items-center ${isSidebarOpen ? 'justify-start' : 'justify-center'} mb-3`}>
                <img  
                  alt={user.email || 'Avatar de Usuario'} 
                  className="h-10 w-10 rounded-full object-cover border-2 border-primary"
                 src="https://images.unsplash.com/photo-1691398495617-18457fbf826d" />
                <AnimatePresence>
                {isSidebarOpen && (
                  <motion.div 
                    variants={linkVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                    transition={{ duration: 0.2, delay: 0.1 }}
                    className="ml-3 overflow-hidden"
                  >
                    <p className="text-sm font-medium text-foreground truncate">{user.user_metadata?.full_name || user.email}</p>
                    <p className="text-xs text-muted-foreground capitalize flex items-center">
                      <ShieldCheck className="w-3 h-3 mr-1 text-green-500" />{userRole || 'Usuario'}
                    </p>
                  </motion.div>
                )}
                </AnimatePresence>
              </div>
            )}
            <Button
              variant="ghost"
              onClick={handleSignOut}
              className={`w-full text-destructive hover:bg-destructive/10 hover:text-destructive 
              ${isSidebarOpen ? 'justify-start' : 'justify-center'}`}
              title={isSidebarOpen ? '' : 'Cerrar Sesión'}
            >
              <LogOut className="h-5 w-5" />
              <AnimatePresence>
              {isSidebarOpen && (
                <motion.span 
                  variants={linkVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  transition={{ duration: 0.2, delay: 0.1 }}
                  className="ml-3 whitespace-nowrap"
                >
                  Cerrar Sesión
                </motion.span>
              )}
              </AnimatePresence>
            </Button>
          </div>
        </aside>
      );
    };

    export default AdminSidebar;
  