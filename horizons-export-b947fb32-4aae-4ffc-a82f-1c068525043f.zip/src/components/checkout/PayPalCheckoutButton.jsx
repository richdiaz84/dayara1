
    import React, { useState, useEffect } from 'react';
    import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const PayPalCheckoutButton = ({ orderDetails, onSuccess, onError, onProcessing }) => {
      const { toast } = useToast();
      const [paypalClientId, setPaypalClientId] = useState(null);
      const [loadingClientId, setLoadingClientId] = useState(true);

      useEffect(() => {
        const fetchPaypalClientId = async () => {
          setLoadingClientId(true);
          try {
            const { data, error } = await supabase.functions.invoke('get-paypal-client-id');
            if (error) throw error;
            if (data.clientId) {
              setPaypalClientId(data.clientId);
            } else {
              throw new Error("PayPal Client ID no encontrado en la respuesta de la función.");
            }
          } catch (err) {
            console.error("Error fetching PayPal Client ID:", err);
            toast({ variant: "destructive", title: "Error de Configuración de PayPal", description: "No se pudo cargar la configuración de PayPal. Intenta más tarde."});
            onError("Error de configuración de PayPal.");
          } finally {
            setLoadingClientId(false);
          }
        };
        fetchPaypalClientId();
      }, [toast, onError]);

      const createOrder = async (data, actions) => {
        onProcessing(true);
        try {
          const { data: functionData, error } = await supabase.functions.invoke('create-paypal-order', {
            body: {
              purchase_units: [{
                amount: {
                  currency_code: 'MXN', 
                  value: orderDetails.total.toFixed(2),
                  breakdown: {
                    item_total: {
                      currency_code: 'MXN',
                      value: orderDetails.subtotal.toFixed(2)
                    },
                    shipping: {
                      currency_code: 'MXN',
                      value: orderDetails.shipping_cost.toFixed(2)
                    },
                    tax_total: {
                      currency_code: 'MXN',
                      value: orderDetails.tax_amount.toFixed(2)
                    }
                  }
                },
                items: orderDetails.items.map(item => ({
                  name: item.name.substring(0, 127),
                  quantity: item.quantity.toString(),
                  unit_amount: {
                    currency_code: 'MXN',
                    value: item.price.toFixed(2)
                  },
                  sku: item.id.substring(0,127)
                }))
              }]
            }
          });

          if (error) {
            console.error("Error creando orden en PayPal (Edge Function):", error);
            throw new Error(`Error en servidor al crear orden PayPal: ${error.message}`);
          }
          
          if (functionData && functionData.orderId) {
            return functionData.orderId;
          } else {
            throw new Error("Respuesta inválida de la función create-paypal-order.");
          }

        } catch (err) {
          console.error('Error al crear la orden de PayPal:', err);
          toast({ variant: "destructive", title: "Error de PayPal", description: `No se pudo crear la orden de PayPal: ${err.message}` });
          onError(`Error al crear la orden de PayPal: ${err.message}`);
          onProcessing(false);
          return null; 
        }
      };

      const onApprove = async (data, actions) => {
        try {
          const { data: functionData, error } = await supabase.functions.invoke('capture-paypal-order', {
            body: { orderID: data.orderID }
          });

          if (error) {
            console.error("Error capturando pago en PayPal (Edge Function):", error);
            throw new Error(`Error en servidor al capturar pago PayPal: ${error.message}`);
          }

          if (functionData && functionData.status === 'COMPLETED') {
            onSuccess(functionData.id, functionData); 
          } else {
            throw new Error(functionData.details?.[0]?.description || "El pago no pudo ser completado por PayPal.");
          }

        } catch (err) {
          console.error('Error al capturar el pago de PayPal:', err);
          toast({ variant: "destructive", title: "Error de PayPal", description: `No se pudo completar el pago: ${err.message}` });
          onError(`Error al completar el pago: ${err.message}`);
        } finally {
          onProcessing(false);
        }
      };
      
      const onPayPalError = (err) => {
        console.error("Error de PayPal SDK:", err);
        toast({ variant: "destructive", title: "Error de PayPal", description: "Ocurrió un error con PayPal. Por favor, intenta de nuevo o usa otro método de pago." });
        onError("Error con PayPal SDK.");
        onProcessing(false);
      };

      if (loadingClientId) {
        return <div className="text-center py-4 text-muted-foreground">Cargando opciones de pago...</div>;
      }

      if (!paypalClientId) {
        return <div className="text-center py-4 text-destructive">Error al cargar la configuración de PayPal.</div>;
      }

      return (
        <PayPalScriptProvider options={{ "client-id": paypalClientId, currency: "MXN", intent: "capture" }}>
          <PayPalButtons
            style={{ layout: "vertical", color: "blue", shape: "rect", label: "pay", tagline: false }}
            createOrder={createOrder}
            onApprove={onApprove}
            onError={onPayPalError}
            onCancel={() => {
              toast({ variant: "info", title: "Pago Cancelado", description: "Cancelaste el proceso de pago con PayPal." });
              onProcessing(false);
            }}
            onClick={() => onProcessing(true)}
          />
        </PayPalScriptProvider>
      );
    };

    export default PayPalCheckoutButton;
  